import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { immeublesService, decomptesEauService } from '../../services/api';
import { 
  ArrowLeft, Plus, Building2, Droplets, Calendar, 
  FileText, CheckCircle, AlertCircle, ChevronRight 
} from 'lucide-react';

export default function ImmeubleDecomptes() {
  const { immeubleId } = useParams();
  const navigate = useNavigate();
  const [immeuble, setImmeuble] = useState(null);
  const [decomptes, setDecomptes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [immeubleId]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Charger immeuble
      const immeubleRes = await immeublesService.getOne(immeubleId);
      setImmeuble(immeubleRes.data.immeuble);

      // Charger tous les décomptes et filtrer
      const decomptesRes = await decomptesEauService.getAll();
      const allDecomptes = decomptesRes.data.decomptes || [];
      const immeubleDecomptes = allDecomptes.filter(d => d.immeuble_id === immeubleId);
      
      setDecomptes(immeubleDecomptes);

    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDecompte = () => {
    // Naviguer vers page création avec immeubleId en query param
    navigate(`/decomptes/nouveau?immeubleId=${immeubleId}`);
  };

  const getStatusBadge = (statut) => {
    const configs = {
      brouillon: { 
        bg: 'bg-gray-100', 
        text: 'text-gray-800', 
        icon: FileText,
        label: '📝 Brouillon' 
      },
      calcule: { 
        bg: 'bg-green-100', 
        text: 'text-green-800', 
        icon: CheckCircle,
        label: '✓ Calculé' 
      },
      valide: { 
        bg: 'bg-blue-100', 
        text: 'text-blue-800', 
        icon: CheckCircle,
        label: '✓ Validé' 
      },
      cloture: { 
        bg: 'bg-red-100', 
        text: 'text-red-800', 
        icon: AlertCircle,
        label: '🔒 Clôturé' 
      }
    };

    const config = configs[statut] || configs.brouillon;
    
    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        {config.label}
      </span>
    );
  };

  const getModeLabel = (mode) => {
    const labels = {
      divisionnaire: 'Divisionnaire',
      collectif: 'Collectif',
      individuel: 'Individuel',
      principal_uniquement: 'Principal uniquement'
    };
    return labels[mode] || mode;
  };

  // Grouper par année
  const decomptesByYear = decomptes.reduce((acc, decompte) => {
    const year = decompte.annee;
    if (!acc[year]) {
      acc[year] = [];
    }
    acc[year].push(decompte);
    return acc;
  }, {});

  const years = Object.keys(decomptesByYear).sort((a, b) => b - a);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!immeuble) {
    return (
      <div className="text-center py-12">
        <Building2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900">Immeuble introuvable</h3>
        <button
          onClick={() => navigate('/decomptes')}
          className="mt-4 text-blue-600 hover:text-blue-700"
        >
          Retour aux décomptes
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/decomptes')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Building2 className="h-7 w-7 text-blue-600" />
              {immeuble.nom}
            </h1>
            <p className="text-gray-600 mt-1">
              {decomptes.length} décompte{decomptes.length > 1 ? 's' : ''} d'eau
              {immeuble.adresse && ` • ${immeuble.adresse}`}
            </p>
          </div>
        </div>

        <button
          onClick={handleCreateDecompte}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          Nouveau décompte
        </button>
      </div>

      {/* Liste des décomptes par année */}
      <div className="space-y-6">
        {years.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
            <Droplets className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucun décompte créé
            </h3>
            <p className="text-gray-600 mb-6">
              Créez votre premier décompte d'eau pour cet immeuble
            </p>
            <button
              onClick={handleCreateDecompte}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="h-5 w-5 mr-2" />
              Créer un décompte
            </button>
          </div>
        ) : (
          years.map(year => (
            <div key={year} className="bg-white rounded-lg shadow-sm border border-gray-200">
              {/* Année */}
              <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-gray-600" />
                  {year}
                  <span className="text-sm font-normal text-gray-600">
                    ({decomptesByYear[year].length} décompte{decomptesByYear[year].length > 1 ? 's' : ''})
                  </span>
                </h2>
              </div>

              {/* Décomptes de l'année */}
              <div className="divide-y divide-gray-200">
                {decomptesByYear[year].map(decompte => (
                  <button
                    key={decompte.id}
                    onClick={() => navigate(`/decomptes/${decompte.id}`)}
                    className="w-full p-6 hover:bg-gray-50 transition-colors text-left group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        {/* Titre et badges */}
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {decompte.nom || `Décompte ${decompte.annee}`}
                          </h3>
                          {getStatusBadge(decompte.statut)}
                        </div>

                        {/* Infos */}
                        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(decompte.periode_debut).toLocaleDateString('fr-FR')}
                            {' → '}
                            {new Date(decompte.periode_fin).toLocaleDateString('fr-FR')}
                          </span>

                          {decompte.mode_comptage_eau && (
                            <span className="flex items-center gap-1">
                              <Droplets className="h-4 w-4" />
                              {getModeLabel(decompte.mode_comptage_eau)}
                            </span>
                          )}

                          {decompte.fournisseur_nom && (
                            <span className="text-gray-500">
                              {decompte.fournisseur_nom}
                            </span>
                          )}
                        </div>

                        {/* Description ou notes */}
                        {decompte.description && (
                          <p className="text-sm text-gray-500 mt-2">
                            {decompte.description}
                          </p>
                        )}
                      </div>

                      {/* Action */}
                      <div className="flex items-center gap-2 text-blue-600 group-hover:text-blue-700 ml-4">
                        <span className="text-sm font-medium">
                          {decompte.statut === 'brouillon' ? 'Continuer' : 'Ouvrir'}
                        </span>
                        <ChevronRight className="h-5 w-5" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Info helper */}
      {decomptes.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Droplets className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-blue-900">
                Gestion des décomptes
              </h3>
              <p className="text-sm text-blue-800 mt-1">
                Cliquez sur un décompte pour configurer les compteurs, saisir les relevés, 
                calculer les répartitions et valider le décompte.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
