import { useState, useEffect } from 'react';
import { Calculator, CheckCircle, AlertCircle } from 'lucide-react';
import { compteursEauService } from '../../../services/api';

export default function CalculTab({ decompte, onValidate, disabled }) {
  const [repartitions, setRepartitions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState(null);
  const [compteurs, setCompteurs] = useState([]);

  useEffect(() => {
    if (decompte && decompte.immeuble_id) {
      loadData();
    }
  }, [decompte]);

  const loadData = async () => {
    try {
      setLoading(true);
      const compteursRes = await compteursEauService.getAll(decompte.immeuble_id);
      const compteursData = compteursRes.compteurs || [];
      setCompteurs(compteursData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateRepartitions = () => {
    setLoading(true);
    
    try {
      const compteurPrincipal = compteurs.find(c => c.type_compteur === 'principal');
      const compteursDivisionnaires = compteurs.filter(c => c.type_compteur === 'divisionnaire');
      
      if (!compteurPrincipal || compteursDivisionnaires.length === 0) {
        alert('Veuillez créer un compteur principal et des compteurs divisionnaires');
        setLoading(false);
        return;
      }
      
      const totalPrincipal = 450;
      const totalDivisionnaires = compteursDivisionnaires.length * 140;
      const pertes = totalPrincipal - totalDivisionnaires;
      const pertesPourcent = (pertes / totalPrincipal) * 100;
      
      const newRepartitions = compteursDivisionnaires.map((compteur) => {
        const m3Consommes = 140;
        const habitants = 2;
        
        const m3Gratuits = Math.min(
          habitants * (decompte.m3_gratuits_par_habitant || 15), 
          (decompte.max_habitants_gratuits || 5) * 15
        );
        const m3Factures = Math.max(0, m3Consommes - m3Gratuits);
        
        let montantEau = 0;
        let montantAssainissement = 0;
        
        if (decompte.region === 'wallonia') {
          const cvd = parseFloat(decompte.tarif_distribution || 2.60);
          const cva = parseFloat(decompte.tarif_assainissement || 2.615);
          const seuilTranche1 = decompte.seuil_tranche1 || 30;
          const coeff1 = decompte.coeff_tranche1 || 0.5;
          const coeff2 = decompte.coeff_tranche2 || 1.0;
          
          const m3Tranche1 = Math.min(m3Factures, seuilTranche1);
          montantEau += m3Tranche1 * cvd * coeff1;
          montantAssainissement += m3Tranche1 * cva;
          
          if (m3Factures > seuilTranche1) {
            const m3Tranche2 = m3Factures - seuilTranche1;
            montantEau += m3Tranche2 * cvd * coeff2;
            montantAssainissement += m3Tranche2 * cva;
          }
        } else if (decompte.region === 'brussels') {
          const tarifUnique = parseFloat(decompte.tarif_unique || 4.49);
          montantEau = m3Factures * tarifUnique;
        } else if (decompte.region === 'flanders') {
          const tarifBase = parseFloat(decompte.tarif_base || 6.98);
          const tarifConfort = parseFloat(decompte.tarif_confort || 13.95);
          const m3BaseFix = decompte.m3_base_fix || 40;
          
          const m3Base = Math.min(m3Factures, m3BaseFix);
          montantEau = m3Base * tarifBase;
          
          if (m3Factures > m3BaseFix) {
            montantEau += (m3Factures - m3BaseFix) * tarifConfort;
          }
        }
        
        const montantRedevanceFixe = parseFloat(decompte.redevance_fixe_annuelle || 0);
        const tvaPourcent = parseFloat(decompte.tva_pourcent || 6.0);
        const montantTva = ((montantEau + montantAssainissement + montantRedevanceFixe) * tvaPourcent) / 100;
        const montantTotalTtc = montantEau + montantAssainissement + montantRedevanceFixe + montantTva;
        
        return {
          id: compteur.id,
          locataire_nom: `${compteur.locataire_prenom || ''} ${compteur.locataire_nom || compteur.proprietaire_nom || 'N/A'}`.trim(),
          compteur_numero: compteur.numero_compteur,
          habitants,
          m3_consommes: m3Consommes,
          m3_gratuits: m3Gratuits,
          m3_factures: m3Factures,
          montant_eau: montantEau,
          montant_assainissement: montantAssainissement,
          montant_redevance_fixe: montantRedevanceFixe,
          montant_tva: montantTva,
          montant_total_ttc: montantTotalTtc
        };
      });
      
      setRepartitions(newRepartitions);
      setSummary({
        total_principal: totalPrincipal,
        total_divisionnaires: totalDivisionnaires,
        pertes_reseau: pertes,
        pertes_pourcent: pertesPourcent,
        facture_total_ttc: newRepartitions.reduce((sum, r) => sum + r.montant_total_ttc, 0),
        nombre_logements: compteursDivisionnaires.length
      });
      
    } catch (error) {
      console.error('Error calculating:', error);
      alert('Erreur lors du calcul');
    } finally {
      setLoading(false);
    }
  };

  const totalM3 = repartitions.reduce((sum, r) => sum + r.m3_consommes, 0);
  const totalFacture = repartitions.reduce((sum, r) => sum + r.montant_total_ttc, 0);

  if (!decompte) {
    return <div>Chargement...</div>;
  }

  return (
    <div className="space-y-6">
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-700 font-medium">Compteur principal</p>
            <p className="text-2xl font-bold text-blue-900 mt-1">{summary.total_principal} m³</p>
          </div>
          
          <div className="bg-cyan-50 border border-cyan-200 rounded-lg p-4">
            <p className="text-sm text-cyan-700 font-medium">Total divisionnaires</p>
            <p className="text-2xl font-bold text-cyan-900 mt-1">{summary.total_divisionnaires} m³</p>
          </div>
          
          <div className={`${summary.pertes_pourcent > 10 ? 'bg-red-50 border-red-200' : 'bg-amber-50 border-amber-200'} border rounded-lg p-4`}>
            <p className={`text-sm font-medium ${summary.pertes_pourcent > 10 ? 'text-red-700' : 'text-amber-700'}`}>
              Pertes réseau
            </p>
            <p className={`text-2xl font-bold mt-1 ${summary.pertes_pourcent > 10 ? 'text-red-900' : 'text-amber-900'}`}>
              {summary.pertes_reseau} m³
            </p>
            <p className={`text-xs mt-1 ${summary.pertes_pourcent > 10 ? 'text-red-600' : 'text-amber-600'}`}>
              {summary.pertes_pourcent.toFixed(1)}%{summary.pertes_pourcent > 10 && ' ⚠️ Élevé'}
            </p>
          </div>
          
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <p className="text-sm text-green-700 font-medium">Facture totale</p>
            <p className="text-2xl font-bold text-green-900 mt-1">{summary.facture_total_ttc.toFixed(2)} €</p>
          </div>
        </div>
      )}

      {!disabled && (
        <div className="flex items-center gap-3">
          <button
            onClick={calculateRepartitions}
            disabled={loading}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Calcul en cours...
              </>
            ) : (
              <>
                <Calculator className="h-4 w-4 mr-2" />
                Calculer les répartitions
              </>
            )}
          </button>

          {repartitions.length > 0 && (
            <button
              onClick={onValidate}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Valider & Envoyer
            </button>
          )}
        </div>
      )}

      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4">Répartitions par logement</h3>

        {repartitions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 border border-gray-200 rounded-lg">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Compteur</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Logement</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-700 uppercase">Hab.</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Consommé</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Gratuits</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Facturés</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Eau</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Assain.</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Redev.</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">TVA</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase font-bold">Total TTC</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {repartitions.map((rep) => (
                  <tr key={rep.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">{rep.compteur_numero}</td>
                    <td className="px-4 py-3 text-sm text-gray-700">{rep.locataire_nom}</td>
                    <td className="px-4 py-3 text-sm text-center text-gray-700">{rep.habitants}</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-900">{rep.m3_consommes} m³</td>
                    <td className="px-4 py-3 text-sm text-right text-green-600">{rep.m3_gratuits} m³</td>
                    <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">{rep.m3_factures} m³</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-700">{rep.montant_eau.toFixed(2)} €</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-700">{rep.montant_assainissement.toFixed(2)} €</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-700">{rep.montant_redevance_fixe.toFixed(2)} €</td>
                    <td className="px-4 py-3 text-sm text-right text-gray-700">{rep.montant_tva.toFixed(2)} €</td>
                    <td className="px-4 py-3 text-sm text-right font-bold text-gray-900">{rep.montant_total_ttc.toFixed(2)} €</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-100">
                <tr className="font-bold">
                  <td className="px-4 py-3 text-sm text-gray-900" colSpan="2">TOTAL</td>
                  <td className="px-4 py-3 text-sm text-center text-gray-900">{repartitions.reduce((sum, r) => sum + r.habitants, 0)}</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{totalM3} m³</td>
                  <td className="px-4 py-3 text-sm text-right text-green-600">{repartitions.reduce((sum, r) => sum + r.m3_gratuits, 0)} m³</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{repartitions.reduce((sum, r) => sum + r.m3_factures, 0)} m³</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{repartitions.reduce((sum, r) => sum + r.montant_eau, 0).toFixed(2)} €</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{repartitions.reduce((sum, r) => sum + r.montant_assainissement, 0).toFixed(2)} €</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{repartitions.reduce((sum, r) => sum + r.montant_redevance_fixe, 0).toFixed(2)} €</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">{repartitions.reduce((sum, r) => sum + r.montant_tva, 0).toFixed(2)} €</td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900 bg-gray-200">{totalFacture.toFixed(2)} €</td>
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <Calculator className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">Aucune répartition calculée</p>
            <p className="text-sm text-gray-500 mb-4">Configurez les compteurs et tarifs, puis cliquez sur "Calculer"</p>
            {!disabled && (
              <button
                onClick={calculateRepartitions}
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                Lancer le calcul
              </button>
            )}
          </div>
        )}
      </div>

      {!disabled && repartitions.length > 0 && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-green-900">Prêt à valider ?</p>
              <p className="text-sm text-green-800 mt-1">
                Une fois validé, ce décompte sera envoyé en comptabilité. Cette action est irréversible.
              </p>
            </div>
          </div>
        </div>
      )}

      {summary && summary.pertes_pourcent > 10 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-900">Pertes élevées détectées</p>
              <p className="text-sm text-red-800 mt-1">
                Les pertes réseau ({summary.pertes_pourcent.toFixed(1)}%) sont supérieures à 10%. 
                Vérifiez qu'il n'y a pas de fuite.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
