import { useState, useEffect } from 'react';
import { compteursEauService, relevesService } from '../../../services/api';
import { Activity, Calendar, Save, AlertCircle } from 'lucide-react';

export default function RelevesTab({ decompte, onUpdate, disabled }) {
  const [compteurs, setCompteurs] = useState([]);
  const [releves, setReleves] = useState({});
  const [dateReleve, setDateReleve] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (decompte?.immeuble_id) {
      loadCompteurs();
      setDateReleve(new Date().toISOString().split('T')[0]);
    }
  }, [decompte?.immeuble_id]);

  const loadCompteurs = async () => {
    try {
      setLoading(true);
      const data = await compteursEauService.getAll(decompte.immeuble_id);
      const compteursData = data.compteurs || [];
      
      const compteursDivisionnaires = compteursData.filter(c => c.type_compteur === 'divisionnaire');
      setCompteurs(compteursDivisionnaires);
      
      const initialReleves = {};
      compteursDivisionnaires.forEach(c => {
        initialReleves[c.id] = {
          digits: ['0','0','0','0','0','0','0','0','0','0']
        };
      });
      setReleves(initialReleves);
      
    } catch (error) {
      console.error('Error loading compteurs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDigitChange = (compteurId, digitIndex, value) => {
    if (!/^\d*$/.test(value)) return;
    
    setReleves(prev => ({
      ...prev,
      [compteurId]: {
        ...prev[compteurId],
        digits: prev[compteurId].digits.map((d, i) => 
          i === digitIndex ? value.slice(-1) : d
        )
      }
    }));
  };

  const calculateIndex = (digits) => {
    const integerPart = digits.slice(0, 6).join('');
    const decimalPart = digits.slice(6, 10).join('');
    return parseFloat(`${integerPart}.${decimalPart}`);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      
      const relevesData = Object.keys(releves).map(compteurId => ({
        compteur_id: parseInt(compteurId),
        date_releve: dateReleve,
        index: calculateIndex(releves[compteurId].digits)
      }));

      await relevesService.bulkImport(decompte.id, relevesData);
      alert('Relevés sauvegardés avec succès');
      
    } catch (error) {
      console.error('Error saving releves:', error);
      alert('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-600"></div>
      </div>
    );
  }

  if (!decompte || !decompte.immeuble_id) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
        <Activity className="h-12 w-12 text-blue-400 mx-auto mb-3" />
        <p className="text-gray-700 font-medium mb-2">Saisie des relevés</p>
        <p className="text-sm text-gray-600">
          Complétez d'abord l'onglet "Infos" puis créez les compteurs dans "Compteurs".
        </p>
      </div>
    );
  }

  if (compteurs.length === 0) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 text-center">
        <AlertCircle className="h-12 w-12 text-amber-400 mx-auto mb-3" />
        <p className="text-gray-700 font-medium mb-2">Aucun compteur divisionnaire</p>
        <p className="text-sm text-gray-600">
          Créez d'abord des compteurs divisionnaires dans l'onglet "Compteurs".
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header style compagnie des eaux */}
      <div className="bg-white border-2 border-gray-300 rounded-lg p-6">
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Installation n°
            </label>
            <input
              type="text"
              value={decompte.immeuble_nom || ''}
              disabled
              className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-700"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Adresse :
            </label>
            <input
              type="text"
              value={decompte.immeuble_nom || ''}
              disabled
              className="w-full px-3 py-2 border border-gray-300 rounded bg-gray-50 text-gray-700"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Relevé d'index en date du :
          </label>
          <input
            type="date"
            value={dateReleve}
            onChange={(e) => setDateReleve(e.target.value)}
            disabled={disabled}
            className="px-4 py-2 border-2 border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 text-lg"
          />
        </div>
      </div>

      {/* Liste des compteurs - style compagnie des eaux */}
      <div className="space-y-4">
        {compteurs.map((compteur, index) => {
          const nomPersonne = compteur.locataire_nom 
            ? `${compteur.locataire_prenom || ''} ${compteur.locataire_nom}`.trim()
            : compteur.proprietaire_nom 
            ? `${compteur.proprietaire_prenom || ''} ${compteur.proprietaire_nom}`.trim()
            : 'N/A';

          return (
            <div key={compteur.id} className="bg-white border-2 border-gray-300 rounded-lg p-6">
              {/* Label compteur style compagnie des eaux */}
              <div className="mb-4 flex items-center gap-4">
                <div className="bg-cyan-500 text-white px-4 py-2 rounded font-medium min-w-[120px]">
                  Compteur :
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900 text-lg">{nomPersonne}</p>
                  <p className="text-sm text-gray-600">{compteur.numero_compteur}</p>
                  {compteur.emplacement && (
                    <p className="text-xs text-gray-500 mt-1">📍 {compteur.emplacement}</p>
                  )}
                </div>
              </div>

              {/* Saisie index avec cases */}
              <div className="flex items-center gap-2 justify-center py-4">
                {/* 6 chiffres avant virgule */}
                {releves[compteur.id]?.digits.slice(0, 6).map((digit, digitIdx) => (
                  <input
                    key={`int-${digitIdx}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleDigitChange(compteur.id, digitIdx, e.target.value)}
                    disabled={disabled}
                    className="w-12 h-14 text-center text-2xl font-mono border-2 border-gray-400 rounded focus:border-blue-500 focus:ring-2 focus:ring-blue-200 disabled:bg-gray-100"
                  />
                ))}
                
                {/* Virgule */}
                <span className="text-4xl font-bold text-gray-500 mx-1">,</span>
                
                {/* 4 chiffres après virgule */}
                {releves[compteur.id]?.digits.slice(6, 10).map((digit, digitIdx) => (
                  <input
                    key={`dec-${digitIdx}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleDigitChange(compteur.id, 6 + digitIdx, e.target.value)}
                    disabled={disabled}
                    className="w-12 h-14 text-center text-2xl font-mono border-2 border-gray-400 rounded focus:border-blue-500 focus:ring-2 focus:ring-blue-200 disabled:bg-gray-100"
                  />
                ))}
                
                {/* Unité */}
                <span className="ml-3 text-xl text-gray-700 font-medium">m³</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Actions */}
      {!disabled && (
        <div className="flex justify-end gap-3 pt-4 border-t-2">
          <button
            onClick={handleSave}
            disabled={saving || !dateReleve}
            className="flex items-center px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
          >
            <Save className="h-5 w-5 mr-2" />
            {saving ? 'Sauvegarde...' : 'Enregistrer les relevés'}
          </button>
        </div>
      )}

      {/* Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          💡 <strong>Conseil :</strong> Saisissez les index exactement comme ils apparaissent sur votre compteur. 
          Prenez une photo pour conserver une preuve du relevé.
        </p>
      </div>
    </div>
  );
}
