import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { decomptesEauService, immeublesService } from '../../services/api';
import { FileText, Droplets, Euro, Calculator, ArrowLeft, Save, CheckCircle, Activity } from 'lucide-react';

// Import des composants d'onglets
import InfosTab from './tabs/InfosTab';
import CompteursTab from './tabs/CompteursTab';
import RelevesTab from './tabs/RelevesTab';
import TarifsTab from './tabs/TarifsTab';
import CalculTab from './tabs/CalculTab';

export default function DecompteDetail() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('infos');
  const [decompte, setDecompte] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const tabs = [
    { 
      id: 'infos', 
      label: 'Infos', 
      icon: FileText,
      description: 'Configuration générale'
    },
    { 
      id: 'compteurs', 
      label: 'Compteurs', 
      icon: Droplets,
      description: 'Gestion des compteurs'
    },
    { 
      id: 'releves', 
      label: 'Relevés', 
      icon: Activity,
      description: 'Saisie des index'
    },
    { 
      id: 'tarifs', 
      label: 'Tarifs', 
      icon: Euro,
      description: 'Prix et règles de facturation'
    },
    { 
      id: 'calcul', 
      label: 'Calcul', 
      icon: Calculator,
      description: 'Répartitions et validation'
    }
  ];

  useEffect(() => {
    if (id && id !== 'nouveau') {
      loadDecompte();
    } else if (id === 'nouveau') {
      const immeubleId = searchParams.get('immeubleId');
      
      if (!immeubleId) {
        navigate('/decomptes');
        return;
      }

      loadImmeubleForCreation(immeubleId);
    } else {
      setLoading(false);
    }
  }, [id, searchParams]);

  const loadDecompte = async () => {
    if (!id || id === 'nouveau') return;
    
    try {
      setLoading(true);
      const data = await decomptesEauService.getById(id);
      setDecompte(data.data?.decompte || data.decompte);
    } catch (error) {
      console.error('Error loading decompte:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadImmeubleForCreation = async (immeubleId) => {
    try {
      setLoading(true);
      
      const immeubleRes = await immeublesService.getOne(immeubleId);
      const immeuble = immeubleRes.data.immeuble;

      setDecompte({
        annee: new Date().getFullYear(),
        periode_debut: `${new Date().getFullYear()}-01-01`,
        periode_fin: `${new Date().getFullYear()}-12-31`,
        statut: 'brouillon',
        immeuble_id: immeuble.id,
        immeuble_nom: immeuble.nom,
        mode_comptage_eau: null,
        region: null,
        fournisseur_id: null
      });

    } catch (error) {
      console.error('Error loading immeuble:', error);
      navigate('/decomptes');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      if (id === 'nouveau') {
        const result = await decomptesEauService.create(decompte);
        const newId = result.data?.decompte?.id || result.decompte?.id;
        navigate(`/decomptes/${newId}`);
      } else {
        await decomptesEauService.update(id, decompte);
      }
    } catch (error) {
      console.error('Error saving:', error);
      alert('Erreur lors de la sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  const handleValidate = async () => {
    if (!confirm('Valider ce décompte ? Il sera envoyé automatiquement en comptabilité.')) {
      return;
    }

    try {
      setSaving(true);
      await decomptesEauService.validate(id);
      loadDecompte();
    } catch (error) {
      console.error('Error validating:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleBack = () => {
    navigate('/decomptes');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!decompte && id !== 'nouveau') {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Décompte introuvable</p>
        <button
          onClick={() => navigate('/decomptes')}
          className="mt-4 text-blue-600 hover:text-blue-700"
        >
          Retour aux décomptes
        </button>
      </div>
    );
  }

  if (!decompte) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const TabIcon = tabs.find(t => t.id === activeTab)?.icon || FileText;

  return (
    <div className="container mx-auto px-4 py-6 max-w-7xl">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={handleBack}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour
        </button>

        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                {id === 'nouveau' ? 'Nouveau Décompte Eau' : `Décompte Eau ${decompte.annee}`}
              </h1>
              <p className="text-gray-600">
                {decompte.immeuble_nom || 'Sélectionnez un immeuble'}
              </p>
              {id !== 'nouveau' && (
                <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                  <span>
                    📅 Période : {new Date(decompte.periode_debut).toLocaleDateString('fr-FR')} 
                    → {new Date(decompte.periode_fin).toLocaleDateString('fr-FR')}
                  </span>
                  <span className={`
                    px-3 py-1 rounded-full text-xs font-medium
                    ${decompte.statut === 'valide' ? 'bg-green-100 text-green-800' : 
                      decompte.statut === 'brouillon' ? 'bg-gray-100 text-gray-800' : 
                      'bg-yellow-100 text-yellow-800'}
                  `}>
                    {decompte.statut === 'valide' ? '✓ Validé' : 
                     decompte.statut === 'brouillon' ? '📝 Brouillon' : 
                     '⏳ En cours'}
                  </span>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleSave}
                disabled={saving || decompte.statut === 'valide'}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="h-4 w-4 mr-2" />
                {saving ? 'Sauvegarde...' : id === 'nouveau' ? 'Créer' : 'Enregistrer'}
              </button>

              {id !== 'nouveau' && decompte.statut !== 'valide' && (
                <button
                  onClick={handleValidate}
                  disabled={saving}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Valider & Envoyer
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    group relative px-6 py-4 flex items-center gap-3 font-medium transition-colors flex-1
                    ${isActive 
                      ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}
                  `}
                >
                  <Icon className={`h-5 w-5 ${isActive ? 'text-blue-600' : 'text-gray-400 group-hover:text-gray-600'}`} />
                  <div className="text-left">
                    <div className="font-medium">{tab.label}</div>
                    <div className="text-xs text-gray-500 hidden md:block">{tab.description}</div>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {!decompte ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <>
              {activeTab === 'infos' && (
                <InfosTab 
                  decompte={decompte} 
                  onUpdate={setDecompte}
                  disabled={decompte.statut === 'valide'}
                />
              )}
              {activeTab === 'compteurs' && (
                <CompteursTab 
                  decompte={decompte}
                  onUpdate={setDecompte}
                  disabled={decompte.statut === 'valide'}
                />
              )}
              {activeTab === 'releves' && (
                <RelevesTab 
                  decompte={decompte}
                  onUpdate={setDecompte}
                  disabled={decompte.statut === 'valide'}
                />
              )}
              {activeTab === 'tarifs' && (
                <TarifsTab 
                  decompte={decompte}
                  onUpdate={setDecompte}
                  disabled={decompte.statut === 'valide'}
                />
              )}
              {activeTab === 'calcul' && (
                <CalculTab 
                  decompte={decompte}
                  onValidate={handleValidate}
                  disabled={decompte.statut === 'valide'}
                />
              )}
            </>
          )}
        </div>
      </div>

      {/* Helper info */}
      {decompte && decompte.statut !== 'valide' && (
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <TabIcon className="h-5 w-5 text-blue-600 mt-0.5" />
            </div>
            <div className="ml-3 flex-1">
              <h3 className="text-sm font-medium text-blue-900">
                {activeTab === 'infos' && 'Configuration générale'}
                {activeTab === 'compteurs' && 'Gestion des compteurs'}
                {activeTab === 'releves' && 'Saisie des relevés'}
                {activeTab === 'tarifs' && 'Configuration des tarifs'}
                {activeTab === 'calcul' && 'Calcul et validation'}
              </h3>
              <div className="mt-2 text-sm text-blue-800">
                {activeTab === 'infos' && (
                  <p>Configurez le mode de comptage, la région et le fournisseur d'eau pour cet exercice.</p>
                )}
                {activeTab === 'compteurs' && (
                  <p>Créez la hiérarchie des compteurs (principal → divisionnaires).</p>
                )}
                {activeTab === 'releves' && (
                  <p>Entrez les relevés d'index pour chaque compteur divisionnaire avec cases individuelles.</p>
                )}
                {activeTab === 'tarifs' && (
                  <p>Définissez les prix de l'eau selon le tarif du fournisseur (CVD, CVA, m³ gratuits, etc.).</p>
                )}
                {activeTab === 'calcul' && (
                  <p>Vérifiez les répartitions calculées et validez le décompte pour l'envoyer en comptabilité.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
