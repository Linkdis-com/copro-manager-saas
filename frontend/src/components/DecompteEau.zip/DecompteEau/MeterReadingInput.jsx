import { useState, useRef } from 'react';
import { Calendar } from 'lucide-react';

/**
 * Composant de saisie de relevé de compteur
 * Style : Cases individuelles comme sur l'image 1
 */
export default function MeterReadingInput({ 
  compteur, 
  value = '', 
  onChange,
  installationNumber = '',
  readingDate = ''
}) {
  const [digits, setDigits] = useState(value.padEnd(10, ' ').split('').slice(0, 10));
  const [dateDigits, setDateDigits] = useState(() => {
    if (readingDate) {
      const [year, month, day] = readingDate.split('-');
      return `${day}${month}${year}`.padEnd(8, ' ').split('').slice(0, 8);
    }
    return '        '.split('');
  });
  
  const inputRefs = useRef([]);
  const dateRefs = useRef([]);

  // Gestion saisie compteur (10 chiffres)
  const handleDigitChange = (index, value) => {
    if (!/^\d*$/.test(value) && value !== '') return;

    const newDigits = [...digits];
    newDigits[index] = value.slice(-1);
    setDigits(newDigits);

    // Appeler onChange avec la valeur complète
    const fullValue = newDigits.join('').trim();
    onChange(fullValue);

    // Auto-focus next input
    if (value && index < 9) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  // Gestion backspace
  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  // Gestion saisie date (8 chiffres: DDMMYYYY)
  const handleDateChange = (index, value) => {
    if (!/^\d*$/.test(value) && value !== '') return;

    const newDigits = [...dateDigits];
    newDigits[index] = value.slice(-1);
    setDateDigits(newDigits);

    // Formatter en date ISO
    if (newDigits.every(d => d.trim())) {
      const day = newDigits.slice(0, 2).join('');
      const month = newDigits.slice(2, 4).join('');
      const year = newDigits.slice(4, 8).join('');
      // Note: Appeler un callback onDateChange si nécessaire
    }

    // Auto-focus next input
    if (value && index < 7) {
      dateRefs.current[index + 1]?.focus();
    }
  };

  const handleDateKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !dateDigits[index] && index > 0) {
      dateRefs.current[index - 1]?.focus();
    }
  };

  return (
    <div className="space-y-4">
      {/* Installation n° */}
      {installationNumber && (
        <div className="text-sm text-gray-700">
          <span className="font-medium">Installation n°</span>
          <span className="ml-2">{installationNumber}</span>
        </div>
      )}

      {/* Date de relevé */}
      <div className="flex items-center gap-2">
        <Calendar className="h-4 w-4 text-gray-600" />
        <span className="text-sm font-medium text-gray-700">Relevé d'index en date du :</span>
        
        <div className="flex items-center gap-1">
          {/* Jour (2 chiffres) */}
          {[0, 1].map((index) => (
            <input
              key={`day-${index}`}
              ref={(el) => (dateRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength="1"
              value={dateDigits[index] || ''}
              onChange={(e) => handleDateChange(index, e.target.value)}
              onKeyDown={(e) => handleDateKeyDown(index, e)}
              className="w-8 h-10 text-center border-2 border-gray-300 rounded focus:border-blue-500 focus:outline-none text-lg font-mono"
            />
          ))}
          
          <span className="text-gray-400 mx-1">-</span>
          
          {/* Mois (2 chiffres) */}
          {[2, 3].map((index) => (
            <input
              key={`month-${index}`}
              ref={(el) => (dateRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength="1"
              value={dateDigits[index] || ''}
              onChange={(e) => handleDateChange(index, e.target.value)}
              onKeyDown={(e) => handleDateKeyDown(index, e)}
              className="w-8 h-10 text-center border-2 border-gray-300 rounded focus:border-blue-500 focus:outline-none text-lg font-mono"
            />
          ))}
          
          <span className="text-gray-400 mx-1">-</span>
          
          {/* Année (4 chiffres) */}
          {[4, 5, 6, 7].map((index) => (
            <input
              key={`year-${index}`}
              ref={(el) => (dateRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength="1"
              value={dateDigits[index] || ''}
              onChange={(e) => handleDateChange(index, e.target.value)}
              onKeyDown={(e) => handleDateKeyDown(index, e)}
              className={`w-8 h-10 text-center border-2 rounded focus:border-blue-500 focus:outline-none text-lg font-mono ${
                index === 4 || index === 5 ? 'border-gray-300' : 'border-gray-300'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Compteur avec label cyan */}
      <div className="flex items-center gap-3">
        {/* Label compteur */}
        <div className="flex-shrink-0 bg-cyan-600 text-white px-4 py-2 rounded font-medium text-sm min-w-[120px]">
          Compteur :
        </div>
        
        {/* 10 cases pour les chiffres */}
        <div className="flex items-center gap-1 flex-1">
          {digits.map((digit, index) => (
            <input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength="1"
              value={digit.trim()}
              onChange={(e) => handleDigitChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className={`w-10 h-12 text-center border-2 rounded focus:border-cyan-500 focus:outline-none text-lg font-mono ${
                digit.trim() ? 'border-cyan-400 bg-cyan-50' : 'border-gray-300'
              }`}
            />
          ))}
          
          {/* Virgule */}
          <span className="text-2xl font-bold text-gray-400 mx-1">,</span>
          
          {/* Dernières cases pour décimales (colorées différemment) */}
          {[8, 9].map((index) => (
            <input
              key={`decimal-${index}`}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              inputMode="numeric"
              maxLength="1"
              value={digits[index]?.trim() || ''}
              onChange={(e) => handleDigitChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className={`w-10 h-12 text-center border-2 rounded focus:border-orange-500 focus:outline-none text-lg font-mono ${
                digits[index]?.trim() ? 'border-orange-400 bg-orange-50' : 'border-gray-300'
              }`}
            />
          ))}
          
          {/* Unité */}
          <span className="ml-2 text-sm font-medium text-gray-600">m³</span>
        </div>
      </div>

      {/* Info compteur */}
      {compteur && (
        <div className="text-xs text-gray-500 ml-[136px]">
          {compteur.numero_compteur}
          {compteur.emplacement && ` • ${compteur.emplacement}`}
        </div>
      )}
    </div>
  );
}

/**
 * EXEMPLE D'UTILISATION :
 * 
 * <MeterReadingInput
 *   compteur={compteur}
 *   value="123456"
 *   onChange={(value) => handleReadingChange(compteur.id, value)}
 *   installationNumber="12345"
 *   readingDate="2026-01-25"
 * />
 */
