import { useState, useEffect } from 'react';
import { 
  CreditCard, Building2, Users, Calendar, ArrowRight, 
  AlertCircle, CheckCircle, Gift, FileText, Percent, ShoppingCart, Plus,
  X, Loader, Tag
} from 'lucide-react';
import { Link } from 'react-router-dom';

const API_URL = import.meta.env.VITE_API_URL || '';

function SubscriptionTab() {
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [usage, setUsage] = useState({ immeubles: 0, unites: 0 });
  const [discounts, setDiscounts] = useState([]);
  const [plans, setPlans] = useState([]);

  // ═══════════════════════════════════════════════════════════
  // 🎁 NOUVEAUX STATES POUR CODES PROMO
  // ═══════════════════════════════════════════════════════════
  const [promoCode, setPromoCode] = useState('');
  const [promoValidating, setPromoValidating] = useState(false);
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState(null);
  const [activePromos, setActivePromos] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const token = localStorage.getItem('token');
      const headers = { 'Authorization': `Bearer ${token}` };

      // Charger les données en parallèle
      const [subRes, plansRes, discountsRes, promosRes] = await Promise.all([
        fetch(`${API_URL}/api/v1/subscription/current`, { headers }),
        fetch(`${API_URL}/api/v1/plans`, { headers }),
        fetch(`${API_URL}/api/v1/referral/my-discounts`, { headers }),
        fetch(`${API_URL}/api/v1/promo/my-discounts`, { headers }) // ✅ NOUVEAU
      ]);

      if (subRes.ok) {
        const data = await subRes.json();
        setSubscription(data.subscription);
        setUsage(data.subscription.usage || { immeubles: 0, unites: 0 });
      }

      if (plansRes.ok) {
        const data = await plansRes.json();
        setPlans(data.plans || []);
      }

      if (discountsRes.ok) {
        const data = await discountsRes.json();
        setDiscounts(data.discounts || []);
      }

      // ✅ NOUVEAU : Charger les promos actives
      if (promosRes.ok) {
        const data = await promosRes.json();
        setActivePromos(data.discounts || []);
      }

    } catch (error) {
      console.error('Error loading subscription data:', error);
    } finally {
      setLoading(false);
    }
  };

  // ═══════════════════════════════════════════════════════════
  // 🎁 VALIDATION CODE PROMO
  // ═══════════════════════════════════════════════════════════
  const validatePromoCode = async () => {
    if (!promoCode.trim()) {
      setPromoError('Veuillez saisir un code promo');
      return;
    }

    setPromoValidating(true);
    setPromoError('');
    setPromoSuccess(null);

    try {
      const token = localStorage.getItem('token');
      
      // 1. Valider le code
      const validateResponse = await fetch(`${API_URL}/api/v1/promo/validate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ code: promoCode.trim().toUpperCase() })
      });

      const validateData = await validateResponse.json();

      if (validateResponse.ok && validateData.valid) {
        // 2. Appliquer le code
        const applyResponse = await fetch(`${API_URL}/api/v1/promo/apply`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ code: promoCode.trim().toUpperCase() })
        });

        if (applyResponse.ok) {
          const applyData = await applyResponse.json();
          setPromoSuccess(validateData.message || 'Code promo appliqué avec succès ! 🎉');
          setPromoCode('');
          
          // Recharger toutes les données pour mettre à jour le pricing
          await loadData();
          
          // Faire disparaître le message de succès après 5 secondes
          setTimeout(() => setPromoSuccess(null), 5000);
        } else {
          const errorData = await applyResponse.json();
          setPromoError(errorData.message || 'Erreur lors de l\'application du code');
        }
      } else {
        setPromoError(validateData.message || 'Code promo invalide');
      }
    } catch (error) {
      console.error('Error validating promo code:', error);
      setPromoError('Erreur de connexion. Veuillez réessayer.');
    } finally {
      setPromoValidating(false);
    }
  };

  // ═══════════════════════════════════════════════════════════
  // 💰 CALCUL DU PRIX (MODIFIÉ POUR INCLURE PROMOS)
  // ═══════════════════════════════════════════════════════════
  const calculatePrice = () => {
    if (!subscription?.plan) return { 
      units: 0, 
      pricePerUnit: 0, 
      baseYearly: 0, 
      discountPercent: 0, 
      discountAmount: 0,
      freeMonths: 0,
      freeUnits: 0,
      subtotal: 0, 
      vatRate: 0, 
      vatAmount: 0, 
      total: 0 
    };

    const plan = subscription.plan;
    const units = usage.unites || 0;
    const pricePerUnit = parseFloat(plan.price_monthly) || 0;
    
    // ✅ NOUVEAU : Calculer mois gratuits depuis les promos
    const freeMonthsFromPromos = activePromos
      .filter(p => p.reward_type === 'free_months')
      .reduce((sum, p) => sum + (p.reward_value || 0), 0);
    
    // ✅ NOUVEAU : Calculer unités gratuites depuis les promos
    const freeUnitsFromPromos = activePromos
      .filter(p => p.reward_type === 'free_units')
      .reduce((sum, p) => sum + (p.reward_value || 0), 0);
    
    // ✅ NOUVEAU : Calculer % de réduction depuis les promos
    const percentDiscountFromPromos = activePromos
      .filter(p => p.reward_type === 'percentage')
      .reduce((max, p) => Math.max(max, p.reward_value || 0), 0);
    
    // Réduction parrainage (existante)
    const discountPercent = discounts.length > 0 
      ? Math.max(...discounts.map(d => d.percentage))
      : 0;

    // Calcul avec mois gratuits
    const monthsCharged = Math.max(0, 12 - freeMonthsFromPromos);
    const chargedUnits = Math.max(0, units - freeUnitsFromPromos);
    
    const baseYearly = units * pricePerUnit * 12;
    const baseAfterFreeMonths = (baseYearly / 12) * monthsCharged;
    
    // Appliquer % de réduction (promo + parrainage)
    const totalDiscountPercent = Math.max(discountPercent, percentDiscountFromPromos);
    const discountAmount = baseAfterFreeMonths * (totalDiscountPercent / 100);
    
    const subtotal = baseAfterFreeMonths - discountAmount;
    const vatRate = plan.is_professional ? 21 : 0;
    const vatAmount = subtotal * (vatRate / 100);
    const total = subtotal + vatAmount;

    return {
      units,
      pricePerUnit,
      baseYearly,
      freeMonths: freeMonthsFromPromos,
      freeUnits: freeUnitsFromPromos,
      monthsCharged,
      chargedUnits,
      discountPercent: totalDiscountPercent,
      discountAmount,
      subtotal,
      vatRate,
      vatAmount,
      total
    };
  };

  const formatAmount = (amount) => {
    return new Intl.NumberFormat('fr-BE', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount || 0);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('fr-BE', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };

  const getStatusBadge = (status, trialEnd) => {
    if (status === 'trialing') {
      const daysLeft = trialEnd 
        ? Math.ceil((new Date(trialEnd) - new Date()) / (1000 * 60 * 60 * 24))
        : 0;
      return (
        <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
          <Calendar className="h-4 w-4" />
          Essai gratuit ({daysLeft > 0 ? `${daysLeft} jours restants` : 'Expiré'})
        </span>
      );
    }
    if (status === 'active') {
      return (
        <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
          <CheckCircle className="h-4 w-4" />
          Actif
        </span>
      );
    }
    if (status === 'expired' || status === 'cancelled') {
      return (
        <span className="inline-flex items-center gap-1 px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">
          <AlertCircle className="h-4 w-4" />
          {status === 'expired' ? 'Expiré' : 'Annulé'}
        </span>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <div className="animate-spin h-8 w-8 border-4 border-primary-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const pricing = calculatePrice();
  const plan = subscription?.plan;
  const maxImmeubles = plan?.max_immeubles === -1 ? 'Illimité' : plan?.max_immeubles;
  const totalUnits = subscription?.total_units || 0;

  return (
    <div className="space-y-6">
      {/* ✅ SECTION 1 : Plan actuel (INCHANGÉE) */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary-600" />
            Votre abonnement
          </h2>
          {subscription && getStatusBadge(subscription.status, subscription.trial_end)}
        </div>

        {subscription ? (
          <div className="space-y-4">
            {/* Nom du plan */}
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-lg ${plan?.is_professional ? 'bg-purple-100' : 'bg-blue-100'}`}>
                <Building2 className={`h-6 w-6 ${plan?.is_professional ? 'text-purple-600' : 'text-blue-600'}`} />
              </div>
              <div>
                <p className="text-xl font-bold text-gray-900">Plan {plan?.name}</p>
                <p className="text-gray-600">
                  {plan?.is_professional 
                    ? `${pricing.pricePerUnit}€ HTVA/unité/mois + TVA 21%`
                    : `${pricing.pricePerUnit}€ TTC/unité/mois`
                  }
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  💡 Facturation annuelle : {pricing.pricePerUnit}€ × {totalUnits} unité{totalUnits > 1 ? 's' : ''} × 12 mois
                </p>
              </div>
            </div>

            {/* Alerte si essai expiré */}
            {subscription.status === 'trialing' && subscription.trial_end && new Date(subscription.trial_end) < new Date() && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-800">Votre période d'essai est terminée</p>
                    <p className="text-sm text-red-700 mt-1">
                      Abonnez-vous pour continuer à utiliser toutes les fonctionnalités.
                    </p>
                    <button className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                      S'abonner maintenant
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Date de renouvellement */}
            {subscription.status === 'active' && subscription.current_period_end && (
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>Prochain renouvellement le {formatDate(subscription.current_period_end)}</span>
              </div>
            )}
          </div>
        ) : (
          <p className="text-gray-600">Aucun abonnement actif</p>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════════
          🎁 NOUVELLE SECTION 2 : CODE PROMO
          ═══════════════════════════════════════════════════════════ */}
      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Gift className="h-5 w-5 text-purple-600" />
          <h2 className="text-lg font-semibold text-gray-900">Code promo</h2>
        </div>

        {/* Formulaire de saisie */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Vous avez un code promo ?
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              onKeyPress={(e) => e.key === 'Enter' && validatePromoCode()}
              placeholder="Ex: WELCOME2025"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent uppercase"
              disabled={promoValidating}
              maxLength={20}
            />
            <button
              onClick={validatePromoCode}
              disabled={promoValidating || !promoCode.trim()}
              className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2 font-medium"
            >
              {promoValidating ? (
                <>
                  <Loader className="h-4 w-4 animate-spin" />
                  <span className="hidden sm:inline">Vérification...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">Appliquer</span>
                </>
              )}
            </button>
          </div>

          {/* Message d'erreur */}
          {promoError && (
            <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 animate-shake">
              <X className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{promoError}</p>
            </div>
          )}

          {/* Message de succès */}
          {promoSuccess && (
            <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg flex items-start gap-2 animate-slide-down">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-green-700 font-medium">{promoSuccess}</p>
            </div>
          )}
        </div>

        {/* Liste des promos actives */}
        {activePromos.length > 0 && (
          <div className="mt-4 pt-4 border-t border-purple-200">
            <p className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
              <Tag className="h-4 w-4" />
              Vos promotions actives
            </p>
            <div className="space-y-2">
              {activePromos.map((promo, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-lg border border-purple-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 rounded-full">
                      <Gift className="h-4 w-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">
                        {promo.promo_code || `Parrainage ${promo.referrer_name || ''}`}
                      </p>
                      <p className="text-sm text-purple-600 font-medium">
                        {promo.reward_type === 'free_months' && `🎁 ${promo.reward_value} mois gratuits`}
                        {promo.reward_type === 'free_units' && `🎁 ${promo.reward_value} unités gratuites`}
                        {promo.reward_type === 'percentage' && `💰 -${promo.reward_value}% de réduction`}
                      </p>
                    </div>
                  </div>
                  {promo.expires_at && (
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      Expire le {formatDate(promo.expires_at)}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ✅ SECTION 3 : Utilisation (INCHANGÉE) */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Votre utilisation</h2>
          <button className="inline-flex items-center gap-2 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-primary-600 hover:bg-primary-50 border border-primary-200 transition-colors">
            <Plus className="h-4 w-4" />
            Acheter des unités
          </button>
        </div>
        
        <div className="grid md:grid-cols-3 gap-4">
          {/* Unités achetées */}
          <div className="p-4 bg-white rounded-lg shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Unités achetées</span>
              <ShoppingCart className="h-4 w-4 text-primary-500" />
            </div>
            <p className="text-3xl font-bold text-primary-600">{totalUnits}</p>
            <p className="text-xs text-gray-500 mt-1">
              {formatAmount(totalUnits * pricing.pricePerUnit)}/mois
            </p>
          </div>

          {/* Unités utilisées */}
          <div className="p-4 bg-white rounded-lg shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Unités utilisées</span>
              <Users className="h-4 w-4 text-gray-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">{usage.unites}</p>
            <p className="text-xs text-gray-500 mt-1">
              {usage.immeubles} immeuble{usage.immeubles > 1 ? 's' : ''}
            </p>
          </div>

          {/* Unités disponibles */}
          <div className="p-4 bg-white rounded-lg shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Unités disponibles</span>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </div>
            <p className="text-3xl font-bold text-green-600">{totalUnits - usage.unites}</p>
            <p className="text-xs text-gray-500 mt-1">
              Prêtes à utiliser
            </p>
          </div>
        </div>

        {/* Barre de progression */}
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Utilisation des unités</span>
            <span>{usage.unites} / {totalUnits}</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-primary-500 to-purple-500 transition-all duration-300"
              style={{ width: `${totalUnits > 0 ? (usage.unites / totalUnits) * 100 : 0}%` }}
            />
          </div>
        </div>

        {/* Info immeubles */}
        <div className="mt-4 p-3 bg-white rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-700">Immeubles</span>
            </div>
            <span className="font-semibold text-gray-900">
              {usage.immeubles} / {maxImmeubles}
            </span>
          </div>
          {plan?.max_immeubles === 1 && usage.immeubles >= 1 && (
            <p className="text-xs text-amber-600 mt-2">
              💡 Passez en Pro pour gérer plusieurs immeubles
            </p>
          )}
        </div>
      </div>

      {/* ✅ SECTION 4 : Tarif calculé (MODIFIÉE POUR PROMOS) */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Votre tarif <span className="text-primary-600">ANNUEL</span>
        </h2>
        
        <div className="space-y-3">
          <div className="flex justify-between text-gray-600">
            <span>{pricing.units} unité{pricing.units > 1 ? 's' : ''} × {formatAmount(pricing.pricePerUnit)}/mois × 12 mois</span>
            <span className="font-medium">{formatAmount(pricing.baseYearly)}</span>
          </div>
          
          {/* ✅ NOUVEAU : Afficher mois gratuits */}
          {pricing.freeMonths > 0 && (
            <div className="flex justify-between text-purple-600">
              <span className="flex items-center gap-1">
                <Gift className="h-4 w-4" />
                Mois gratuits ({pricing.freeMonths} mois offerts)
              </span>
              <span className="font-medium">-{formatAmount((pricing.baseYearly / 12) * pricing.freeMonths)}</span>
            </div>
          )}
          
          {/* Réduction pourcentage */}
          {pricing.discountPercent > 0 && (
            <div className="flex justify-between text-green-600">
              <span className="flex items-center gap-1">
                <Percent className="h-4 w-4" />
                Réduction ({pricing.discountPercent}%)
              </span>
              <span className="font-medium">-{formatAmount(pricing.discountAmount)}</span>
            </div>
          )}
          
          {plan?.is_professional && (
            <>
              <div className="border-t border-gray-200 pt-2 flex justify-between text-gray-600">
                <span>Sous-total HTVA</span>
                <span className="font-medium">{formatAmount(pricing.subtotal)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>TVA ({pricing.vatRate}%)</span>
                <span className="font-medium">{formatAmount(pricing.vatAmount)}</span>
              </div>
            </>
          )}
          
          <div className="border-t-2 border-gray-900 pt-3 flex justify-between">
            <span className="font-bold text-gray-900">Total TTC par an</span>
            <span className="text-2xl font-bold text-primary-600">{formatAmount(pricing.total)}</span>
          </div>

          {/* Info mensuelle et mois facturés */}
          <div className="mt-2 space-y-2">
            {pricing.freeMonths > 0 && (
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-800">
                  🎉 Vous ne payez que <strong>{pricing.monthsCharged} mois</strong> sur 12 grâce à vos promos !
                </p>
              </div>
            )}
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                💡 Soit environ <strong>{formatAmount(pricing.total / 12)}</strong> par mois
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ✅ SECTION 5 : Réductions actives (parrainage - INCHANGÉE) */}
      {discounts.length > 0 && (
        <div className="bg-green-50 rounded-xl border border-green-200 p-6">
          <h2 className="text-lg font-semibold text-green-800 mb-4 flex items-center gap-2">
            <Gift className="h-5 w-5" />
            Vos réductions parrainage
          </h2>
          
          <div className="space-y-2">
            {discounts.map((discount, index) => (
              <div key={index} className="flex justify-between items-center p-3 bg-white rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{discount.reason || discount.type}</p>
                  {discount.expires_at && (
                    <p className="text-xs text-gray-500">
                      Expire le {formatDate(discount.expires_at)}
                    </p>
                  )}
                </div>
                <span className="font-bold text-green-600">-{discount.percentage}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ✅ SECTION 6 : Comparaison des plans (INCHANGÉE) */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Comparer les plans</h2>
        
        <div className="grid md:grid-cols-2 gap-4">
          {/* Plan Particulier */}
          <div className={`p-4 rounded-xl border-2 ${
            plan?.code === 'particulier' ? 'border-primary-500 bg-primary-50' : 'border-gray-200'
          }`}>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-gray-900">Particulier</h3>
              {plan?.code === 'particulier' && (
                <span className="px-2 py-1 bg-primary-600 text-white text-xs rounded-full">Actuel</span>
              )}
            </div>
            <p className="text-2xl font-bold text-gray-900 mb-1">
              2€ <span className="text-sm font-normal text-gray-500">TTC/unité/mois</span>
            </p>
            <p className="text-xs text-gray-500 mb-3">Facturation annuelle : 24€/unité/an</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                1 immeuble maximum
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Décomptes eau illimités
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Export PDF
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Support email
              </li>
            </ul>
            {plan?.code !== 'particulier' && (
              <button className="mt-4 w-full py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                Changer de plan
              </button>
            )}
          </div>

          {/* Plan Professionnel */}
          <div className={`p-4 rounded-xl border-2 ${
            plan?.code === 'professionnel' ? 'border-purple-500 bg-purple-50' : 'border-gray-200'
          }`}>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-gray-900">Professionnel</h3>
              {plan?.code === 'professionnel' && (
                <span className="px-2 py-1 bg-purple-600 text-white text-xs rounded-full">Actuel</span>
              )}
            </div>
            <p className="text-2xl font-bold text-gray-900 mb-1">
              4€ <span className="text-sm font-normal text-gray-500">HTVA/unité/mois</span>
            </p>
            <p className="text-xs text-gray-500 mb-3">Facturation annuelle : 48€ HTVA/unité/an</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Multi-immeubles illimités
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                TVA récupérable (21%)
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Tout le plan Particulier
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Support prioritaire
              </li>
            </ul>
            {plan?.code !== 'professionnel' && (
              <button className="mt-4 w-full py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center gap-2">
                Passer en Pro
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ✅ SECTION 7 : Lien vers factures (INCHANGÉE) */}
      <Link 
        to="/settings/invoices" 
        className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
      >
        <div className="flex items-center gap-3">
          <FileText className="h-5 w-5 text-gray-500" />
          <span className="font-medium text-gray-700">Voir mes factures</span>
        </div>
        <ArrowRight className="h-5 w-5 text-gray-400" />
      </Link>
    </div>
  );
}

export default SubscriptionTab;
